var n = require("E83F86F5A957E1DF8E59EEF2533A0DF1.js");

App({
    onLaunch: function(n) {},
    onShow: function(n) {},
    onError: function(n) {},
    util: n,
    userInfo: {
        sessionid: null
    },
    siteInfo: require("765C30A5A957E1DF103A58A2D2C90DF1.js")
});