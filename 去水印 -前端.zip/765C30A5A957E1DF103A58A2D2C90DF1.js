module.exports = {
    uniacid: "4",
    acid: "4",
    multiid: "0",
    version: "2.0",
  siteroot: "https://wx.muzzz.cn/app/index.php",
    design_method: "3"
};