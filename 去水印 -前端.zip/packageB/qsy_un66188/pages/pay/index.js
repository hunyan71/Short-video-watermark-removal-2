// packageB/qsy_un66188/pages/pay/index.js
Page({data: {}})