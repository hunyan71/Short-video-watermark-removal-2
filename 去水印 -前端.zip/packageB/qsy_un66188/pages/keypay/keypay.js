// packageB/qsy_un66188/pages/keypay/keypay.js
Page({data: {}})