// packageA/qsy_un66188/pages/shibai/index.js
Page({data: {}})