// packageA/qsy_un66188/pages/user/user.js
Page({data: {}})