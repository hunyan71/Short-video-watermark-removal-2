// packageA/qsy_un66188/pages/cishu/index.js
Page({data: {}})