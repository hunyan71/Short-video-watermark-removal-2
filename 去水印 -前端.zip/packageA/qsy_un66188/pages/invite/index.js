// packageA/qsy_un66188/pages/invite/index.js
Page({data: {}})